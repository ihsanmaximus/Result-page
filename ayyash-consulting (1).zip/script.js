(function () {
  "use strict";
  var roots = document.querySelectorAll("[data-mx-nav]");
  Array.prototype.forEach.call(roots, function (root) {
    var toggle = root.querySelector("[data-mx-toggle]");
    if (!toggle) return;
    var panel = document.getElementById(toggle.getAttribute("aria-controls"));
    var mq = root.getAttribute("data-mx-mq");
    function setOpen(open) {
      root.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Tutup menu" : "Buka menu");
    }
    toggle.addEventListener("click", function () {
      setOpen(!root.classList.contains("is-open"));
    });
    if (panel) {
      panel.addEventListener("click", function (event) {
        var target = event.target;
        if (target && target.closest && target.closest("a")) setOpen(false);
      });
    }
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && root.classList.contains("is-open")) {
        setOpen(false);
        toggle.focus();
      }
    });
    document.addEventListener("click", function (event) {
      if (root.classList.contains("is-open") && !root.contains(event.target)) setOpen(false);
    });
    if (mq && window.matchMedia) {
      var query = window.matchMedia(mq);
      var onChange = function () { setOpen(false); };
      if (query.addEventListener) query.addEventListener("change", onChange);
      else if (query.addListener) query.addListener(onChange);
    }
  });

  // Link #home / #top tanpa target: gulir ke atas halaman.
  document.addEventListener("click", function (event) {
    var link = event.target && event.target.closest ? event.target.closest('a[href^="#"]') : null;
    if (!link) return;
    var href = link.getAttribute("href");
    if (!href || href === "#") return;
    var id = decodeURIComponent(href.slice(1));
    if (!document.getElementById(id) && (id === "home" || id === "top")) {
      event.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  });
})();
